<div class="welcome" style="width:100%">
<br>
<h1 style="text-align:center">Bienvenue sur notre site.</h1> <br> 
<br>
<h4 style="text-align:center">Veuillez vous inscrire ou vous authentifier pour continuer.</h4>
</div>
<?php require "../app/view/_templates/loginbox.php"; ?>
