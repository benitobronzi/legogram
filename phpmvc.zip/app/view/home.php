<div class="center">
    <div class="welcome">
        Bienvenue <?php $_SESSION["name"]?>
    </div>
</div>
